package com.vehicle.dao;

import java.util.HashMap;

import com.vehicle.dto.Registration;
import com.vehicle.dto.ValidityCheck;

public class VehicleInsuranceDAOImpl implements VehicleInsuranceDAO {
	public Registration registration(Registration reg) {
		
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		print(map);
		map.put(reg.getVehicleType(), reg.getVehicleNo());
		return reg;
	}
	
	private void print(HashMap<String, Integer> map) {
		
	}

	public ValidityCheck validation(ValidityCheck validity ) {
		return validity;
		
	}
}
