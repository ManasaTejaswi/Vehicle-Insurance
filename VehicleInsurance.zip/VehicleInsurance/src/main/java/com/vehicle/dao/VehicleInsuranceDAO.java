package com.vehicle.dao;

import com.vehicle.dto.Registration;
import com.vehicle.dto.ValidityCheck;

public interface VehicleInsuranceDAO {
	Registration registration(Registration reg);
	ValidityCheck validation(ValidityCheck validity );
}
