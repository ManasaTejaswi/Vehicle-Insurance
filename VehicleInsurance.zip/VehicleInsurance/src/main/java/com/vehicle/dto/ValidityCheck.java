package com.vehicle.dto;

public class ValidityCheck {
long insuranceValidityPeriod;
long dateOfRenewal;
public long getInsuranceValidityPeriod() {
	return insuranceValidityPeriod;
}
public void setInsuranceValidityPeriod(long insuranceValidityPeriod) {
	this.insuranceValidityPeriod = insuranceValidityPeriod;
}
public long getDateOfRenewal() {
	return dateOfRenewal;
}
public void setDateOfRenewal(long dateOfRenewal) {
	this.dateOfRenewal = dateOfRenewal;
}

}
