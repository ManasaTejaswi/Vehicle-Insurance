package com.vehicle.ui;

import java.util.Scanner;

import com.vehicle.dto.Registration;
import com.vehicle.dto.ValidityCheck;
import com.vehicle.service.VehicleInsuranceService;
import com.vehicle.service.VehicleInsuranceServiceImpl;

public class MainClass {
public static void main(String args[]) {
	// creating service object
	 VehicleInsuranceService vehicleService=new  VehicleInsuranceServiceImpl();
	 // creating registration dto object
	 Registration registrationObj=new Registration();
	 Scanner input=new Scanner(System.in);
	System.out.println("enter your choice:\n 1.Vehicle Insurance Registration\n 2.Insurance Validity Check\n 3.Exit");
	 int ch=input.nextInt();
	 switch(ch)
	 {
	 case 1:
		 System.out.println("enter vehicle no");
		 registrationObj.setVehicleNo(input.nextInt());
		 System.out.println("enter vehicle type");
		 registrationObj.setVehicleType(input.next());
		 System.out.println("enter the insurance period");
		 registrationObj.setInsurancePeriod(input.nextInt());
		 System.out.println("enter aadhar no");
		 registrationObj.setAadharNo(input.nextLong());
		 System.out.println("enter mobile no");
		 registrationObj.setMobileNo(input.nextLong());
		 
		 // storing all the values into registration service object
		 vehicleService.registration(registrationObj);
		 break;
	 case 2:
		 System.out.println("enter the date of registration");
		 double registrationDate=input.nextDouble();
		 System.out.println("enter the insurance period");
		 registrationObj.setInsurancePeriod(input.nextInt());
		 break;
	 case 3:
		 System.out.println("exit");
			break; 
	 }
		 
		 
}
}
