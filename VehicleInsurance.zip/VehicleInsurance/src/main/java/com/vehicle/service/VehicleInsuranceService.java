package com.vehicle.service;

import com.vehicle.dto.Registration;
import com.vehicle.dto.ValidityCheck;

public interface VehicleInsuranceService {
	Registration registration(Registration reg);
	ValidityCheck validation(ValidityCheck validity );

	}

