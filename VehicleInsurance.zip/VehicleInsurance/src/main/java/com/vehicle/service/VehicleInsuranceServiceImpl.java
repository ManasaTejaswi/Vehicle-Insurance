package com.vehicle.service;

import com.vehicle.dao.VehicleInsuranceDAO;
import com.vehicle.dao.VehicleInsuranceDAOImpl;
import com.vehicle.dto.Registration;
import com.vehicle.dto.ValidityCheck;

public class VehicleInsuranceServiceImpl implements VehicleInsuranceService  {
	//  creating object for dao implementation
	VehicleInsuranceDAO dao=new VehicleInsuranceDAOImpl();
public Registration registration(Registration reg) {
	int obj=reg.getInsurancePeriod();

	// returning all the values to dao 
	return dao.registration(reg) ;
	
}

public ValidityCheck validation(ValidityCheck validity ) {

	return validity;
	
}
}
